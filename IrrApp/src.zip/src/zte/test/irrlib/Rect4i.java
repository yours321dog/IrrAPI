package zte.test.irrlib;

public class Rect4i {
	public Rect4i(int left, int up, int right, int down){
		this.left = left;
		this.right = right;
		this.up = up;
		this.down = down;
	}
	
	public int left, right, up, down;
}
