package zte.test.irrlib;

public class Vector2d {

	public Vector2d(){
		
	}
	
	public Vector2d(double x, double y){
		this.x = x;
		this.y = y;
	}
	
	public double x, y;
}
