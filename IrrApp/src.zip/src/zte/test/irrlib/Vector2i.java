package zte.test.irrlib;

public class Vector2i {
	
	public Vector2i(){
		
	}
	
	public Vector2i(int x, int y){
		this.x = x; this.y = y;
	}
	
	public int x, y;
}
