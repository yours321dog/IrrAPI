package zte.test.irrapp;

import android.util.Log;

public class WLog {
	private static String tag = "Wang Log"; 
	public static void i(String str){
		Log.i(tag, str);
	}
}
